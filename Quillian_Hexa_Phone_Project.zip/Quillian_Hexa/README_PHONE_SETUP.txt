QUILLIAN HEXA — PHONE-ONLY BUILD GUIDE

WHAT THIS IS
A first playable version of Quillian Hexa: minimal portrait interface, Classic,
Endless, Time Attack and Challenge modes, hex-style board tiles, piece placement,
line clearing, score, hint, undo, local best score and offline web caching.

IMPORTANT
This ZIP contains the game source and cloud Android build setup. It is NOT a
compiled APK yet. The APK is produced by GitHub Actions after you upload this
project to a GitHub repository and run the workflow.

PHONE STEPS
1. Extract this ZIP on your Android phone (Files app / ZArchiver).
2. Open github.com in Chrome and sign in or create an account.
3. Create a NEW PUBLIC repository named quillian-hexa.
4. Upload the CONTENTS of this folder (not the outer folder itself).
5. Open the repository's Actions tab.
6. Select "Build Quillian Hexa APK" and press "Run workflow".
7. When it finishes successfully, open the workflow run and download the
   "Quillian-Hexa-debug-APK" artifact.
8. Extract the downloaded artifact ZIP and install app-debug.apk.
   Android may ask you to allow Chrome/files to install unknown apps.

PLAYING OFFLINE
The game itself is designed to run offline. Internet is needed for uploading
the project and building/downloading the APK. After installation, gameplay
does not require an internet connection.

NOTE
This is the initial playable build, not a finished commercial release. Test it
on your phone and tell me what feels wrong; we can improve gameplay, balancing,
visuals, sound and additional features in later versions.
