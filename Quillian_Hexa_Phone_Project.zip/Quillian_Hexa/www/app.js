(() => {
const $=id=>document.getElementById(id);
const SIZE=7, COLORS=["#7181dc","#62a995","#e3a96e","#c17fa5","#6e9fc5"];
const SHAPES=[
 [[0,0],[1,0],[2,0]], [[0,0],[0,1],[1,1]], [[0,0],[1,0],[1,1]],
 [[0,0],[1,0],[2,0],[1,1]], [[0,0],[0,1],[0,2]], [[0,0],[1,0],[1,1],[2,1]],
 [[0,0],[1,0]], [[0,0],[1,0],[2,0],[3,0]], [[0,0],[1,0],[0,1],[1,1]]
];
let board,score,mode,queue,selected=-1,history=[],best=Number(localStorage.qhBest||0),timer=60,tick=null,sound=true,roundTarget=500;
const screens=["homeScreen","gameScreen","resultScreen"];
function show(id){screens.forEach(s=>$(s).classList.toggle("active",s===id))}
function toast(t){const el=$("toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),1500)}
function emptyBoard(){return Array.from({length:SIZE},()=>Array(SIZE).fill(null))}
function randShape(){return SHAPES[Math.floor(Math.random()*SHAPES.length)].map(p=>p.slice())}
function start(m){mode=m;board=emptyBoard();score=0;queue=[randShape(),randShape(),randShape()];selected=-1;history=[];timer=60;roundTarget=500;
$("modeLabel").textContent=({classic:"CLASSIC",endless:"ENDLESS",time:"TIME ATTACK",challenge:"CHALLENGE"})[m];
$("goalLabel").textContent=m==="challenge"?"TARGET":"BEST";$("goalValue").textContent=m==="challenge"?roundTarget:best;
$("timerStat").classList.toggle("hidden",m!=="time");$("statusLine").textContent=m==="challenge"?"Reach 500 points to complete the challenge.":"Choose a piece and place it on the board.";
if(tick)clearInterval(tick);if(m==="time"){tick=setInterval(()=>{timer--; $("timer").textContent=timer;if(timer<=0)finish("Time is up!");},1000)}
render();show("gameScreen")}
function render(){ $("score").textContent=score;$("timer").textContent=timer;
const root=$("board");root.innerHTML="";
for(let r=0;r<SIZE;r++)for(let c=0;c<SIZE;c++){const d=document.createElement("button");d.className="cell"+(board[r][c]?" filled":"");if(board[r][c])d.style.setProperty("--cell-color",board[r][c]);d.setAttribute("aria-label",`row ${r+1}, column ${c+1}`);d.addEventListener("click",()=>placeAt(r,c));root.appendChild(d)}
const tray=$("tray");tray.innerHTML="";queue.forEach((shape,i)=>{const b=document.createElement("button");b.className="piece"+(selected===i?" selected":"");b.disabled=!shape;b.addEventListener("click",()=>{selected=selected===i?-1:i;renderTray()});const mini=document.createElement("div");mini.className="mini-piece";const maxX=Math.max(...(shape||[[0,0]]).map(p=>p[0]));const maxY=Math.max(...(shape||[[0,0]]).map(p=>p[1]));for(let y=0;y<=Math.max(2,maxY);y++)for(let x=0;x<=Math.max(3,maxX);x++){const cell=document.createElement("i");cell.className="mini-cell"+((shape||[]).some(p=>p[0]===x&&p[1]===y)?"":" empty");mini.appendChild(cell)}b.appendChild(mini);tray.appendChild(b)});
$("piecesLeft").textContent=queue.filter(Boolean).length+" AVAILABLE";$("undoBtn").disabled=!history.length}
function renderTray(){render()}
function canPlace(shape,r,c){return shape.every(([x,y])=>r+y<SIZE&&c+x<SIZE&&!board[r+y][c+x])}
function placeAt(r,c){if(selected<0||!queue[selected]){toast("Choose a piece first");return}const shape=queue[selected];if(!canPlace(shape,r,c)){toast("That piece won't fit there");return}
history.push({board:board.map(row=>row.slice()),score,queue:queue.map(s=>s&&s.map(p=>p.slice()))});shape.forEach(([x,y])=>board[r+y][c+x]=COLORS[(score/10|0)%COLORS.length]);score+=shape.length*10;queue[selected]=null;selected=-1;
clearLines();if(mode==="challenge"&&score>=roundTarget){finish("Challenge completed!");return}
if(queue.every(x=>!x)){queue=[randShape(),randShape(),randShape()]}
render();if(!hasAnyMove())finish("No more moves");else $("statusLine").textContent="Nice move. Keep building!"}
function clearLines(){let rows=[],cols=[];for(let r=0;r<SIZE;r++)if(board[r].every(Boolean))rows.push(r);for(let c=0;c<SIZE;c++)if(board.every(row=>row[c]))cols.push(c);
const diag1=[],diag2=[];for(let i=0;i<SIZE;i++){diag1.push(board[i][i]);diag2.push(board[i][SIZE-1-i])}
if(diag1.every(Boolean)){for(let i=0;i<SIZE;i++)board[i][i]=null;score+=100}
if(diag2.every(Boolean)){for(let i=0;i<SIZE;i++)board[i][SIZE-1-i]=null;score+=100}
rows.forEach(r=>board[r].fill(null));cols.forEach(c=>board.forEach(row=>row[c]=null));const n=rows.length+cols.length;if(n){score+=n*100+(n>1?(n-1)*50:0);toast(`${n} line${n>1?"s":""} cleared!`)}}
function hasAnyMove(){return queue.some(shape=>shape&&board.some((row,r)=>row.some((v,c)=>!v&&canPlace(shape,r,c))))}
function finish(message){if(tick)clearInterval(tick);tick=null;best=Math.max(best,score);localStorage.qhBest=best;$("bestHome").textContent=best;$("finalScore").textContent=score;$("resultMessage").textContent=message;$("resultTitle").textContent=mode==="challenge"&&score>=roundTarget?"You did it!":"Nice run.";show("resultScreen")}
function undo(){if(!history.length)return;const h=history.pop();board=h.board;score=h.score;queue=h.queue;selected=-1;render();toast("Last move undone")}
function hint(){if(selected<0){toast("Choose a piece first");return}const shape=queue[selected];for(let r=0;r<SIZE;r++)for(let c=0;c<SIZE;c++)if(canPlace(shape,r,c)){toast(`Try row ${r+1}, column ${c+1}`);return}toast("No space for this piece")}
function restart(){start(mode)}
document.querySelectorAll(".mode-card").forEach(b=>b.addEventListener("click",()=>start(b.dataset.mode)));
$("backBtn").onclick=()=>{if(tick)clearInterval(tick);show("homeScreen")};$("restartBtn").onclick=restart;$("undoBtn").onclick=undo;$("hintBtn").onclick=hint;
$("playAgainBtn").onclick=()=>start(mode);$("resultMenuBtn").onclick=()=>show("homeScreen");
$("soundBtn").onclick=()=>{sound=!sound;$("soundBtn").textContent=sound?"♪":"♫̸";toast(sound?"Sound on":"Sound off")};
$("bestHome").textContent=best;
if("serviceWorker" in navigator && location.protocol!=="file:")navigator.serviceWorker.register("./sw.js").catch(()=>{});
})();